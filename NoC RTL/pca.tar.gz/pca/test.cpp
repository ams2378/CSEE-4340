#include <iostream>
using namespace std; 


int main(){

//Create your pointer
int **ptr;
//Assign first dimension
ptr = new int*[2];
//Assign second dimension
for(int i = 0; i < 2; i++){
	ptr[i] = new int[2];	}

for (int a=0; a<2; a++){
	for (int b=0; b<2; b++){
		ptr[a][b] = a+b;
		cout << "ptr [a][b] : " << ptr[a][b] << endl;
}
	
}

return(0);

}
