
// Final working code; consider '0' pivot element

#include <iostream>
using namespace std;

int n = 3;
//float a[10][11];

float a[3][4] = {
    {1,  -3,  1,  4},
    {2 , -8,  8,  -2},
    {-6, 3, -15, 9}
};

int main(int argc, char *argv[]) {
	int i, j, k, max;
	float t;
	for (i = 0; i < n; ++i) {
		if (a[i][i] == 0){
		//	cout << "inside if " << endl;
			max = i;
			for (j = i + 1; j < n; ++j)
				if (a[j][i] > a[max][i])
					max = j;
		
			for (j = 0; j < n + 1; ++j) {
				t = a[max][j];
				a[max][j] = a[i][j];
				a[i][j] = t;
			}
		}
		else {
			for (j = n; j >= i; --j)
				for (k = i + 1; k < n; ++k)				// i = PIVOT
					a[k][j] -= a[k][i]/a[i][i] * a[i][j];		
		}
	}
		for (k = 0; k < n; ++k) {
			for (j = 0; j < n + 1; ++j)
			cout << a[k][j] << '\t';
			cout << '\n';
		//	cout << a[k][j]/a[k][k] << '\t';				// for normalization
		//	cout << '\n';		
		}
return 0;
}

