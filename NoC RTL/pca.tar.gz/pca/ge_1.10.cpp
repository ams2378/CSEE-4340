// Final working code; with file IO
// working with multiple threads; modification of ge_1.3.cpp which was inherently sequential
// modified to handle '0' in pivots for both single and multithreading. 
// interleaved.. working without 0 pivot
// send receive not working


#define _XOPEN_SOURCE 600
#include <iostream>
#include <fstream>
#include<mpi.h>
#include <iomanip>
#include <math.h>

using namespace std;

	int nrows; 	


int main(int argc, char *argv[]){

	int i,j,k,data,input;
	int mynode, totalnodes;
	double scaling;
	ifstream is ("example.txt");
	ofstream out("output_mpi.txt");

	is >> input;
        nrows = input;
        int ncols = input+1;

	float **ptr = new float*[nrows];
							       
        for(int i = 0; i < nrows; i++){			
                   ptr[i] = new float[ncols];
	}

        for (int a=0; a<nrows; a++){
            for (int b=0; b<ncols; b++){
		is >> data;
		ptr[a][b] = data;
            }
	}
//------------------------------------------------------------MULTIPLE THREADS START HERE------------------------------------------

	MPI_Status status;	
	MPI_Init(&argc,&argv);
	MPI_Comm_size(MPI_COMM_WORLD, &totalnodes);
	MPI_Comm_rank(MPI_COMM_WORLD, &mynode);				

//------------------------------------------------------------
float **finalarray;
	if (mynode==0){
		float **finalarray = new float*[nrows];
			for(int i = 0; i < nrows; i++){			
                	   finalarray[i] = new float[ncols];
			}
	}
//------------------------------------------------------------


	int localrows = nrows/totalnodes;
	int * myrows = new int[localrows];
	float **A_local = new float*[localrows];
	float * tmp = new float[nrows+1];

	int index;

	for (i=0; i<localrows; i++){
		A_local[i] = new float[nrows+1];
		index = mynode + totalnodes*i; 
		myrows[i] = index; 
		
		for (int j=0; j<ncols; j++){
			A_local[i][j] = ptr[index][j];
		}
	}	


	int cnt = 0;
	for(i=0;i<nrows;i++){
			if(i == myrows[cnt]){
				MPI_Bcast(A_local[cnt],nrows+1,MPI_FLOAT, mynode,MPI_COMM_WORLD);
			     if(mynode!=0){			
				MPI_Send(A_local[cnt], (nrows+1)*sizeof(float), MPI_FLOAT, 0,NULL, MPI_COMM_WORLD);	
			     }
			     else{	
				for(j=0;j<nrows+1;j++){
					finalarray[i][j] = A_local[cnt][j];
				}
			     }
				for(j=0;j<nrows+1;j++){
					tmp[j] = A_local[cnt][j];
			//		cout << A_local[cnt][j]<< '\t';
			//		out << A_local[cnt][j] << '\t';
				}		
				cnt++;
			//	cout << '\n';
			//	out << '\n';
			}
			else{
				MPI_Bcast(tmp,nrows+1,MPI_FLOAT,i%totalnodes, MPI_COMM_WORLD);
			}
		
		for(j=cnt;j<localrows;j++){
			scaling = A_local[j][i]/tmp[i];
				for(k=i;k<nrows+1;k++){
					A_local[j][k] = A_local[j][k] - scaling*tmp[k];			
				}
				for (int w=0; w<=i; w++){
					A_local[j][w] = 0;	
				}
		}

	MPI_Barrier(MPI_COMM_WORLD);

//		int y=1;
	if (mynode==0 && i>0){

//		for ( int iter =  1;iter < totalnodes ; iter++) { 
			MPI_Recv(finalarray[], (nrows+1)*sizeof(float), MPI_FLOAT, mynode,NULL, MPI_COMM_WORLD, &status);	
//		}		
	}	
//		y++;

        } //f for for loop

	// For final array outputting 	
	if (mynode==0){
	  for (int r = 0; r < nrows; ++r) {
		for (int c = 0; c < nrows + 1; ++c){
			cout << finalarray[r][c]/finalarray[r][r] << '\t';
			out << finalarray[r][c]/finalarray[r][r]<< '\t';
		}
		out << '\n';
		cout << '\n';
	// cout << a[k][j]/a[k][k] << '\t'; // for normalization
	// cout << '\n';
	}


	}





	MPI_Finalize();

	return(0);

}




