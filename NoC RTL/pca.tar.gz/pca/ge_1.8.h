#include <iostream>


using namespace std;

	int n; 				// n = number of rows
	pthread_mutex_t mutex;

	struct thread_data{
		float** data;
		int pid;
	};

