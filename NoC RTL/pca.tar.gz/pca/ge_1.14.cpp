// Final working code; with file IO
// working with multiple threads; modification of ge_1.3.cpp which was inherently sequential
// modified to handle '0' in pivots for both single and multithreading. 
// interleaved.. working fine
//asynchronous

#define _XOPEN_SOURCE 600
#include <iostream>
#include <fstream>
#include<mpi.h>
#include <iomanip>
#include <math.h>

using namespace std;

	int nrows; 	

int main(int argc, char *argv[]){

	int i,j,k,data,input;
	int mynode, totalnodes;
	double scaling;
	ifstream is ("example.txt");
	ofstream out("output_mpi.txt");

	is >> input;
        nrows = input;
        int ncols = input+1;

	float **ptr = new float*[nrows];
							       
        for(int i = 0; i < nrows; i++){			
                   ptr[i] = new float[ncols];
	}

        for (int a=0; a<nrows; a++){
            for (int b=0; b<ncols; b++){
		is >> data;
		ptr[a][b] = data;
            }
	}

//------------------------------------------------------------MULTIPLE THREADS START HERE------------------------------------------

	MPI_Status status;	
	MPI_Request request;
	MPI_Init(&argc,&argv);
	MPI_Comm_size(MPI_COMM_WORLD, &totalnodes);
	MPI_Comm_rank(MPI_COMM_WORLD, &mynode);				

//------------------------------------------------------------

	float* finalarray;
	finalarray = new float[nrows*ncols];

//------------------------------------------------------------


	int localrows = nrows/totalnodes;
	int * myrows = new int[localrows];
	float **A_local = new float*[localrows];
	float * tmp = new float[nrows+1];
	
	int index;

	for (i=0; i<localrows; i++){
		A_local[i] = new float[nrows+1];
		index = mynode + totalnodes*i; 
		myrows[i] = index; 
		
		for (int j=0; j<ncols; j++){
			A_local[i][j] = ptr[index][j];
		}
	}	

//-------------------------------------------------------------------------------------------------------------------
	int cnt = 0;
	for(i=0;i<nrows;i++){
			if(i == myrows[cnt]){

				MPI_Irecv(&tmp[0],nrows+1,MPI_FLOAT, MPI_ANY_SOURCE, NULL, MPI_COMM_WORLD, &request);

				for (int count=0; count<totalnodes; count++){
					MPI_Isend(&A_local[cnt][0],nrows+1,MPI_FLOAT, count, NULL, MPI_COMM_WORLD, &request);
				}
				MPI_Wait(&request, &status);	
				cnt++;
			}
			else{
				MPI_Irecv(&tmp[0],nrows+1,MPI_FLOAT, MPI_ANY_SOURCE, NULL, MPI_COMM_WORLD, &request);
				if (i%totalnodes == mynode){	
						MPI_Isend(&tmp[0],nrows+1,MPI_FLOAT, mynode, NULL, MPI_COMM_WORLD, &request);
				}
				MPI_Wait(&request, &status);
			}
		for(j=cnt;j<localrows;j++){
			scaling = A_local[j][i]/tmp[i];
				for(k=i;k<nrows+1;k++){
					A_local[j][k] = A_local[j][k] - scaling*tmp[k];			
				}
				for (int w=0; w<=i; w++){
					A_local[j][w] = 0;	
				}
		}
	MPI_Barrier(MPI_COMM_WORLD);
        } 
	
// --------------------------------------------------------------------------------------------------------

	for (int count=0; count < localrows ; count++ ){

			MPI_Gather(&A_local[count][0], (nrows+1), MPI_FLOAT, &finalarray[count*totalnodes*ncols], (nrows+1), MPI_FLOAT, 0, MPI_COMM_WORLD);
		
	}

if (mynode==0){
	for (int i=0; i<nrows; i++){
			cout << '\n';
			out << '\n';
		for (int r = i*ncols; r < (i+1)*ncols; r++){
			cout << finalarray[r]/finalarray[i*ncols +i] << '\t'; 
			out << finalarray[r]/finalarray[i*ncols +i] << '\t'; 
		}
	}
}
		
// --------------------------------------------------------------------------------------------------------
	MPI_Finalize();


	return(0);

}




