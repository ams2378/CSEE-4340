// Final working code; with file IO
// working with multiple threads; modification of ge_1.3.cpp which was inherently sequential
// modified to handle '0' in pivots for both single and multithreading. 
// interleaved.. working 

#define _XOPEN_SOURCE 600
#include <iostream>
#include <fstream>
#include<mpi.h>
#include <iomanip>
#include <math.h>

using namespace std;

	int nrows; 	


int main(int argc, char *argv[]){

	int i,j,k,data,input;
	int mynode, totalnodes;
	double scaling;
	ifstream is ("example.txt");
	ofstream out("output_mpi.txt");

	is >> input;
        nrows = input;
        int ncols = input+1;

	float **ptr = new float*[nrows];
							       
        for(int i = 0; i < nrows; i++){			
                   ptr[i] = new float[ncols];
	}

        for (int a=0; a<nrows; a++){
            for (int b=0; b<ncols; b++){
		is >> data;
		ptr[a][b] = data;
            }
	}

//------------------------------------------------------------MULTIPLE THREADS START HERE------------------------------------------

	MPI_Status status;	
	MPI_Init(&argc,&argv);
	MPI_Comm_size(MPI_COMM_WORLD, &totalnodes);
	MPI_Comm_rank(MPI_COMM_WORLD, &mynode);				

	int localrows = nrows/totalnodes;
	int * myrows = new int[localrows];
	float **A_local = new float*[localrows];
	float * tmp = new float[nrows+1];
	
	int index;

	for (i=0; i<localrows; i++){
		A_local[i] = new float[nrows+1];
		index = mynode + totalnodes*i; 
		myrows[i] = index; 
		
		for (int j=0; j<ncols; j++){
			A_local[i][j] = ptr[index][j];
		}
	}	


	int cnt = 0;
	for(i=0;i<nrows;i++){
//----------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------
			if(i == myrows[cnt]){
//----------------------------------------------------------------------------------------------------------------------------
/*
				if (A_local[i][i] == 0){
					int exchange = 0;
					for (int m=cnt+1; m<localrows; m++){
						if (A_local[m][i] !=0){
							for (int o=0; o<nrows+1; o++){
								float t = A_local[m][o];
								A_local[m][o] = A_local[i][o];
								A_local[i][o] = t;				
							}
						exchange = 1;
						break;		
						}
					}
					if (exchange == 0){
						int nonzerorow = getnonzeropivot( i );
						if ( nonzerorow !=0 )
							cout<<" No non-zero pivot could be found! Exiting "<< endl;
						 		
					}		*/

			//	}



//----------------------------------------------------------------------------------------------------------------------------

				MPI_Bcast(A_local[cnt],nrows+1,MPI_FLOAT, mynode,MPI_COMM_WORLD);			
	
				for(j=0;j<nrows+1;j++){
					tmp[j] = A_local[cnt][j];
					cout << A_local[cnt][j]<< '\t';
					out << A_local[cnt][j] << '\t';
				}		
				cnt++;
				cout << '\n';
				out << '\n';
			}
			else{
				MPI_Bcast(tmp,nrows+1,MPI_FLOAT,i%totalnodes, MPI_COMM_WORLD);
			}
		
		for(j=cnt;j<localrows;j++){
			scaling = A_local[j][i]/tmp[i];
				for(k=i;k<nrows+1;k++){
					A_local[j][k] = A_local[j][k] - scaling*tmp[k];			
				}
				for (int w=0; w<=i; w++){
					A_local[j][w] = 0;	
				}
		}
	MPI_Barrier(MPI_COMM_WORLD);

        } 
	
	MPI_Finalize();

	return(0);

}




