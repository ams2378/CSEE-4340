#include <stdio.h>
#include <stdlib.h>
 
#define ROWS 3
#define COLS 4

float A[ROWS][COLS] = {
    {2,  -3,  2,  4},
    {2 , -8,  8,  -2},
    {-6, 3, -15, 9}
};
 
/* Answer x from Ax=B */

 
int main(int argc, char** argv) {

int i,j,k;

	for (k=0; k<3; k++){
		for (j = k+1; j<4; j++){
			A[k][j] = A[k][j] / A[k][k];
			A[k][k] = 1;
		printf("\n%3.5f ", A[k][j]);
		}
	for (i=k+1; i<3; i++){
		for (j = k+1; j<4; j++){
			A[i][j] = A[i][j] - (A[i][k]*A[k][j]); 
//printf("\n%3.5f ", A[i][j]);
		}
		A[i][k] = 0;	
	}
	}

	for (i=0; i<3; i++){
		for (j = 0; j<4; j++){
	//		  printf("\n%3.5f ", A[i][j]);

		}	
	}
 
}
