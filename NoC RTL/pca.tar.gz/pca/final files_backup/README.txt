---------- CONVERSION TO UPPER TRIANGULAR MATRIX BY USING FORWARD ELIMINATION ----------------------

Assumptions:

(a) Test inputs:

1. Input file: The first line will represnt the number of rows or number of equations. 
2. Number of columns = 1 + number of rows. 1 corresponds to the matrix b of ax=b.

(b) pthread Implementation for Shared Address Space:

1. The code is able to handle pivot element whith ZERO value. Unlike traditional partial pivoting where maximum pivot is calculated before doing forward elimination, here the pivot row with ZERO pivot is just exchanged with the nearest row with NONZERO pivot. It reduecs the computation. 

(c) MPI implementation:

1. It is assumed that the MPI implementation won't solve ZERO pivots.
2. it is assumed that the number of rows will be equally devided with the number of threads. 
