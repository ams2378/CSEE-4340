/*
Description: MPI implementation with interleaved assignment.
Parallel computer architecture, HW1, Spring 2012
AMS2378
AT2769
*/


#define _XOPEN_SOURCE 600
#include <iostream>
#include <fstream>
#include<mpi.h>
#include <iomanip>
#include <math.h>

using namespace std;

	int nrows; 	

int main(int argc, char *argv[]){

	int i,j,k,data,input;
	int mynode, totalnodes;
	double scaling;
	ifstream is ("example.txt");
	ofstream out("output_mpi.txt");

	is >> input;
        nrows = input;
        int ncols = input+1;

	float **ptr = new float*[nrows];
							       
        for(int i = 0; i < nrows; i++){			
                   ptr[i] = new float[ncols];
	}

        for (int a=0; a<nrows; a++){
            for (int b=0; b<ncols; b++){
		is >> data;
		ptr[a][b] = data;
            }
	}

//------------------------------------------------------------MULTIPLE THREADS START HERE------------------------------------------

	MPI_Status status;	
	MPI_Init(&argc,&argv);
	MPI_Comm_size(MPI_COMM_WORLD, &totalnodes);
	MPI_Comm_rank(MPI_COMM_WORLD, &mynode);				
	
		if (nrows%totalnodes !=0){
			cout << "Number of rows is : " << nrows << endl;
			cout << "---------------TO GET THE CORRECT OUPUT NUMBER OF ROWS NEED TO BE EQUALLY DIVISIBLE BY THE NUMBER OF THREAD ---------" << endl;
		}
//------------------------------------------------------------

	float* finalarray;
	finalarray = new float[nrows*ncols];

//------------------------------------------------------------


	int localrows = nrows/totalnodes;
	int * myrows = new int[localrows];
	float **A_local = new float*[localrows];
	float * tmp = new float[nrows+1];
	
	int index;

	for (i=0; i<localrows; i++){
		A_local[i] = new float[nrows+1];
		index = mynode + totalnodes*i; 
		myrows[i] = index; 
		
		for (int j=0; j<ncols; j++){
			A_local[i][j] = ptr[index][j];
		}
	}	


	int cnt = 0;
	for(i=0;i<nrows;i++){
			if(i == myrows[cnt]){
				MPI_Bcast(A_local[cnt],nrows+1,MPI_FLOAT, mynode,MPI_COMM_WORLD);			
	
				for(j=0;j<nrows+1;j++){
					tmp[j] = A_local[cnt][j];

				}		
				cnt++;

			}
			else{
				MPI_Bcast(tmp,nrows+1,MPI_FLOAT,i%totalnodes, MPI_COMM_WORLD);
			}
		
		for(j=cnt;j<localrows;j++){
			scaling = A_local[j][i]/tmp[i];
				for(k=i;k<nrows+1;k++){
					A_local[j][k] = A_local[j][k] - scaling*tmp[k];			
				}
				for (int w=0; w<=i; w++){
					A_local[j][w] = 0;	
				}
		}
	MPI_Barrier(MPI_COMM_WORLD);

        } 
	

// --------------------------------------------------------------------------------------------------------

	for (int count=0; count < localrows ; count++ ){

			MPI_Gather(&A_local[count][0], (nrows+1), MPI_FLOAT, &finalarray[count*totalnodes*ncols], (nrows+1), MPI_FLOAT, 0, MPI_COMM_WORLD);
		
	}


/*	int y=1;
	if (mynode==0){
		for (int r = 0; r < nrows*ncols; ++r) {
			if (r%ncols == 0) {	cout << '\n';	out << '\n'; 	}
				cout << finalarray[r] << '\t';
				out << finalarray[r] << '\t';
		}
	cout << '\n';
	out << '\n';
	}	
*/
	if (mynode==0){
		for (int i=0; i<nrows; i++){
				cout << '\n';
				out << '\n';
			for (int r = i*ncols; r < (i+1)*ncols; r++){
				cout << finalarray[r]/finalarray[i*ncols +i] << '\t'; 
				out << finalarray[r]/finalarray[i*ncols +i] << '\t'; 
			}
		}	
	}
// --------------------------------------------------------------------------------------------------------
	MPI_Finalize();
	delete [] finalarray;
	delete [] ptr;

	return(0);

}




