#include <iostream>
#include <fstream>
using namespace std;

int n;

void forwardSubstitution(float** ptr) {
	float** a;
	a=ptr;
	int i, j, k, max;
	float t;
	for (i = 0; i < n; ++i) {
		max = i;
/*		for (j = i + 1; j < n; ++j)
			if (a[j][i] > a[max][i])
				max = j;
		
		for (j = 0; j < n + 1; ++j) {
			t = a[max][j];
			a[max][j] = a[i][j];
			a[i][j] = t;
		}				*/					

/*		for (int m = i+1; m < n; m++){
			if (a[m][i] != 0){
				for (int o=0; o<n+1; o++){
					t = a[m][o];
					a[m][o] = a[i][o];
					a[i][o] = t;				
				}		
			break;
			}
		}				*/

		
	for (k = i + 1; k < n; ++k){		
		for (j = n; j >= i; --j){
//			for (k = i + 1; k < n; ++k){
				a[k][j] -= a[k][i]/a[i][i] * a[i][j];
			}
			for (int w=0; w<=i; w++){
				a[k][w] = 0;	
			}										
		}	
	}
}

int main(int argc, char *argv[]) {

	ifstream is ("examplex.txt");
	int data;
	float** ptr;
	int input;
        is >> input;
        n = input;
        int row = input;
        int col = input+1;
        ptr = new float*[row];
       
        for(int i = 0; i < row; i++){ 
                ptr[i] = new float[col];
 	}

        for (int a=0; a<row; a++){
            for (int b=0; b<col; b++){
		is >> data;
		ptr[a][b] = data;
           }
	}

	forwardSubstitution(ptr);

	for (int k = 0; k < n; ++k) {
		for (int j = 0; j < n + 1; ++j)
			cout << ptr[k][j] << '\t';
	//		cout << '\n';
	// cout << ptr[k][j]/ptr[k][k] << '\t'; // for normalization
	 cout << '\n';
	}

	
	return 0;
}

