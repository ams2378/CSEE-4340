// Final working code; with file IO
// working with multiple threads; modification of ge_1.3.cpp which was inherently sequential
// modified to handle '0' in pivots for both single and multithreading. 
// block assignment

#define _XOPEN_SOURCE 600
#include <iostream>
#include <fstream>
#include<mpi.h>
#include <iomanip>
#include <math.h>

using namespace std;

	int nrows; 	


int main(int argc, char *argv[]){

	int i,j,k,data,input;
	int mynode, totalnodes;
	double scaling;
	ifstream is ("examplex.txt");
	ofstream out("output_mpi_row.txt");

	is >> input;
        nrows = input;
        int ncols = input+1;

	float **ptr = new float*[nrows];
							       
        for(int i = 0; i < nrows; i++){			
                   ptr[i] = new float[ncols];
	}

        for (int a=0; a<nrows; a++){
            for (int b=0; b<ncols; b++){
		is >> data;
		ptr[a][b] = data;
            }
	}

//------------------------------------------------------------MULTIPLE THREADS START HERE------------------------------------------

	MPI_Status status;	
	MPI_Init(&argc,&argv);
	MPI_Comm_size(MPI_COMM_WORLD, &totalnodes);
	MPI_Comm_rank(MPI_COMM_WORLD, &mynode);				



	float* finalarray;
	finalarray = new float[nrows*ncols];

	int localrows = nrows/totalnodes;
	int * myrows = new int[localrows];
	float **A_local = new float*[localrows];
	float * tmp = new float[nrows+1];
	
	int index;

	for (i=0; i<localrows; i++){
		A_local[i] = new float[nrows+1];
		index = mynode*localrows + i; 
		myrows[i] = index; 
		
		for (int j=0; j<ncols; j++){
			A_local[i][j] = ptr[index][j];
		}
	}	


	int cnt = 0;
	for(i=0;i<nrows;i++){
			if(i == myrows[cnt]){

				MPI_Bcast(&A_local[cnt],nrows+1,MPI_FLOAT, mynode,MPI_COMM_WORLD);			
	
				for(j=0;j<nrows+1;j++){
					tmp[j] = A_local[cnt][j];
					cout << A_local[cnt][j]  << '\t';
//					out << A_local[cnt][j] << '\t';
				}		
				cnt++;
				cout << '\n';
//				out << '\n';
			}
			else{
				MPI_Bcast(&tmp,nrows+1,MPI_FLOAT,i%totalnodes, MPI_COMM_WORLD);
			}
		
		for(j=cnt;j<localrows;j++){
			scaling = A_local[j][i]/tmp[i];
				for(k=i;k<nrows+1;k++){
					A_local[j][k] = A_local[j][k] - scaling*tmp[k];			
				}
				for (int w=0; w<=i; w++){
					A_local[j][w] = 0;	
				}
		}
//	cout<< "At Barrier: Process : "<< mynode << endl;
	MPI_Barrier(MPI_COMM_WORLD);

        } 
	
/*	
	for ( int thrd=0; thrd <totalnodes; thrd++ )  {		
		MPI_Gather(&A_local[0][0], localrows*ncols, MPI_FLOAT, &finalarray[thrd*localrows*ncols], localrows*ncols, MPI_FLOAT, 0, MPI_COMM_WORLD);		
	}
*/

/*	for ( int iter = 0; iter < localrows; iter++ ) {

	MPI_Send(&A_local[iter][0], ncols, MPI_FLOAT, 0,NULL, MPI_COMM_WORLD);
	}
	
	
	if(mynode == 0 )  {
		for ( int iter = 0 ; iter< totalnodes; iter++ ) {		
			MPI_Recv(&finalarray[iter*localrows*ncols], ncols, MPI_FLOAT, iter,NULL, MPI_COMM_WORLD, &status);
		}
	}
*/
	if (mynode==0){
		for (int i=0; i<nrows; i++){
			for (int r = i*ncols; r < (i+1)*ncols; r++){
				cout << finalarray[r] << '\t'; 
				out << finalarray[r]<< '\t'; 
			}
		cout << '\n';
		out << '\n';		
		}
	}
	MPI_Finalize();

	return(0);

}




