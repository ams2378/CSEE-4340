// Routine for the thread:

void *proc (void *thread_arg ) {
// struct thread_data *my_data = thread_arg;
	float **A = thread_arg->input;
	int no_threads = thread_arg->nthread;
	int no_rows = thread_arg->nrows;
	int thread_id = thread_arg->thread_id;

for( int k = 0; k <no_rows - 1; k++) {
	for ( int cr = k+1; cr < no_rows; cr++ ) {
	   if(thread_id == (cr % no_threads)){
		A[cr][k] = A[cr][k] / A[k][k];
			for ( int cc = k+1; cc <= no_rows +1; cc++ ) {
				A[cr][cc] = A[cr][cc] - A[cr][k] * A[k][cc];
			}
	   }
	   else 
		continue;
	}

// Barrier
barrier

} // end for k;

} // end for proc;
