

void* solve(void *thread_arg) {
	struct thread_data* my_data;
	my_data = (struct thread_data*) thread_arg;
	float** a;
	a = my_data->data;
	int id = my_data->pid;

	int i, j, k, max, mystart, final, index;
	float t;
	int range, start;
	float temprange;

	for (i = 0; i < n; ++i) {
//------------------------------------------------------------ ASSIGNMENT OF ROWS --------------------------------
		if (i >= n){
			pthread_barrier_wait(&barr);
			pthread_exit(NULL);
		}					
		temprange = float (n-(i+1))/ (float)NUM_THREAD;
		range = ceil(temprange);
		start = (range*id) + (i+1);
//------------------------------------------------------------- EXCHANGE ROWS FOR PIVOT = 0------------------------------------
	if (a[i][i] == 0){	
		max = i;
		for (int m = mystart; m < n; m=m+NUM_THREAD){
			if (a[m][i] != 0){
				for (int o=0; o<n+1; o++){
					pthread_mutex_lock(&mutex);
					t = a[m][o];
					a[m][o] = a[i][o];
					a[i][o] = t;
					pthread_mutex_unlock(&mutex);				
				}					
			break;	
			}
		}
	}
		pthread_barrier_wait(&barr);
//-------------------------------------------------------------- CORE FORWARD ELIMINATION COMPUTATION LOOP-----------------------
	for (k = start; k < start+range; k++){
	   if(k >= n)
		break;
	   else {
		for (j = n; j >= i; --j){						
						a[k][j] -= a[k][i]/a[i][i] * a[i][j];
		}
		for (int w=0; w<=i; w++){
			a[k][w] = 0;	
		}
	    }	
	}						
	pthread_barrier_wait(&barr);

	}
}
