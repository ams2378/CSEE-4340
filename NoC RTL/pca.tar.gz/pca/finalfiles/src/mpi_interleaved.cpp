/*
Description: MPI implementation with interleaved assignment.
Parallel computer architecture, HW1, Spring 2012
AMS2378
AT2769
*/



#include "mpi_interleaved.h"
#include "mpi_interleaved_func.cpp" 


int main(int argc, char *argv[]){


	is >> input;					// reading the number of rows
        nrows = input;
        ncols = input+1;

	ptr = new float*[nrows];
							       
        for(int i = 0; i < nrows; i++){			
                   ptr[i] = new float[ncols];
	}

        for (int a=0; a<nrows; a++){			// rading the matrix
            for (int b=0; b<ncols; b++){
		is >> data;
		ptr[a][b] = data;
            }
	}

	MPI_Status status;	
	MPI_Init(&argc,&argv);				// initialize
	MPI_Comm_size(MPI_COMM_WORLD, &totalnodes);
	MPI_Comm_rank(MPI_COMM_WORLD, &mynode);				
	
	mpi_interleaved_func();

	return(0);
}

