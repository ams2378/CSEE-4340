
void mpi_interleaved_func(){

//------------------------------------------------------------MULTIPLE THREADS START HERE------------------------------------------


		if (nrows%totalnodes !=0){
			cout << "Number of rows is : " << nrows << endl;
			cout << "---------------TO GET THE CORRECT OUPUT NUMBER OF ROWS NEED TO BE EQUALLY DIVISIBLE BY THE NUMBER OF THREAD ---------" << endl;
		}
//------------------------------------------------------------------------------------------------------------------------------

	float* finalarray;
	finalarray = new float[nrows*ncols];

//---------------------------------------------------------------------ASSIGNMENT-----------------------------------------------------


	int localrows = nrows/totalnodes;
	int * myrows = new int[localrows];
	float **A_local = new float*[localrows];
	float * tmp = new float[nrows+1];
	
	int index;

	for (i=0; i<localrows; i++){
		A_local[i] = new float[nrows+1];						// finding index for rows assigned to each threads
		index = mynode + totalnodes*i; 
		myrows[i] = index; 
		
		for (int j=0; j<ncols; j++){
			A_local[i][j] = ptr[index][j];
		}
	}	

//--------------------------------------------------------------------- MAIN COMPUTATION LOOP-----------------------------------------------
	int cnt = 0;
	for(i=0;i<nrows;i++){
			if(i == myrows[cnt]){
				MPI_Bcast(A_local[cnt],nrows+1,MPI_FLOAT, mynode,MPI_COMM_WORLD);			//broadcasting pivot row		
	
				for(j=0;j<nrows+1;j++){
					tmp[j] = A_local[cnt][j];

				}		
				cnt++;

			}
			else{
				MPI_Bcast(tmp,nrows+1,MPI_FLOAT,i%totalnodes, MPI_COMM_WORLD);
			}
		
		for(j=cnt;j<localrows;j++){									// loop for computing rows bellow the pivot row
			scaling = A_local[j][i]/tmp[i];
				for(k=i;k<nrows+1;k++){
					A_local[j][k] = A_local[j][k] - scaling*tmp[k];			
				}
				for (int w=0; w<=i; w++){
					A_local[j][w] = 0;	
				}
		}
	MPI_Barrier(MPI_COMM_WORLD);

        } 
	

// -------------------------------------------------------------------------RECEIVING FINAL OUTPUT AND SAVING IN FILE---------

	for (int count=0; count < localrows ; count++ ){

			MPI_Gather(&A_local[count][0], (nrows+1), MPI_FLOAT, &finalarray[count*totalnodes*ncols], (nrows+1), MPI_FLOAT, 0, MPI_COMM_WORLD);
		
	}

	if (mynode==0){
		for (int i=0; i<nrows; i++){
				cout << '\n';
				out << '\n';
			for (int r = i*ncols; r < (i+1)*ncols; r++){
				cout << finalarray[r]/finalarray[i*ncols +i] << '\t'; 
				out << finalarray[r]/finalarray[i*ncols +i] << '\t'; 
			}
		}	
	}
// -------------------------------------------------------------------------------------------------------------------------
	MPI_Finalize();
	delete [] finalarray;
	delete [] ptr;
}


