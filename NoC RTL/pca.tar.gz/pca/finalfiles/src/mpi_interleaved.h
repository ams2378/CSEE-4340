#define _XOPEN_SOURCE 600
#include<mpi.h>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <math.h>
using namespace std;

	int nrows;, ncols;	
	int i,j,k,data,input;
	int mynode, totalnodes;
	double scaling;
	float **ptr;
	ifstream is ("example.txt");
	ofstream out("output_mpi_interleaved.txt");


	void mpi_interleaved_func();
