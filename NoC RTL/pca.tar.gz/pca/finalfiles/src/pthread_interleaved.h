
#define _XOPEN_SOURCE 600
#include <iostream>
#include <fstream>
#include<pthread.h>
#include <iomanip>

#define NUM_THREAD 2

using namespace std;

	int n; 				// n = number of rows
	pthread_mutex_t mutex;

	struct thread_data{
		float** data;
		int pid;
	};

	pthread_barrier_t barr;

