#define _XOPEN_SOURCE 600
#include <iostream>
#include <fstream>
#include<mpi.h>
#include <iomanip>
#include <math.h>

using namespace std;

	int nrows; 
	int i,j,k,data,input;
	int mynode, totalnodes;
	double scaling;
	ifstream is ("example.txt");
	ofstream out("output_mpi_interleaved_asyn.txt");
	float **ptr;
	int ncols;

	void mpi_interleaved_asyn_func();
