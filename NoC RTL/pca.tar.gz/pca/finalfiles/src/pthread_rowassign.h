#define _XOPEN_SOURCE 600
#include <iostream>
#include <fstream>
#include<pthread.h>
#include <iomanip>
#include <math.h>
#define NUM_THREAD 3

using namespace std;

	int n; 				// n = number of rows
	pthread_mutex_t mutex;

	struct thread_data{
		float** data;
		int pid;
	};

	pthread_barrier_t barr;
