// Final working code; with file IO
// working with multiple threads; modification of ge_1.3.cpp which was inherently sequential
// modified to handle '0' in pivots for both single and multithreading. 
// interleaved.. working fine, without normalizing


	

int main(int argc, char *argv[]){

	
	is >> input;
        nrows = input;
        ncols = input+1;

	float **ptr = new float*[nrows];
							       
        for(int i = 0; i < nrows; i++){			
                   ptr[i] = new float[ncols];
	}

        for (int a=0; a<nrows; a++){
            for (int b=0; b<ncols; b++){
		is >> data;
		ptr[a][b] = data;
            }
	}

//------------------------------------------------------------MULTIPLE THREADS START HERE------------------------------------------

	MPI_Status status;	
	MPI_Init(&argc,&argv);
	MPI_Comm_size(MPI_COMM_WORLD, &totalnodes);
	MPI_Comm_rank(MPI_COMM_WORLD, &mynode);				

//------------------------------------------------------------

	float* finalarray;
	finalarray = new float[nrows*ncols];

//------------------------------------------------------------


	int localrows = nrows/totalnodes;
	int * myrows = new int[localrows];
	float **A_local = new float*[localrows];
	float * tmp = new float[nrows+1];
	
	int index;

	for (i=0; i<localrows; i++){
		A_local[i] = new float[nrows+1];
		index = mynode*localrows + i; 
		myrows[i] = index; 
		
		for (int j=0; j<ncols; j++){
			A_local[i][j] = ptr[index][j];
		}
	}	


	int cnt = 0;
	for(i=0;i<nrows;i++){
			if(i == myrows[cnt]){
				MPI_Irecv(&tmp[0],nrows+1,MPI_FLOAT, MPI_ANY_SOURCE, NULL, MPI_COMM_WORLD, &request);

				for (int count=0; count<totalnodes; count++){
					MPI_Isend(&A_local[cnt][0],nrows+1,MPI_FLOAT, count, NULL, MPI_COMM_WORLD, &request);		//broadcasting pivot row
				}
				MPI_Wait(&request, &status);	
				cnt++;
			//	cout << '\n';
			}
			else{
				MPI_Irecv(&tmp[0],nrows+1,MPI_FLOAT, MPI_ANY_SOURCE, NULL, MPI_COMM_WORLD, &request);
				if (i%totalnodes == mynode){	
						MPI_Isend(&tmp[0],nrows+1,MPI_FLOAT, mynode, NULL, MPI_COMM_WORLD, &request);
				}
				MPI_Wait(&request, &status);
			}
		
		for(j=cnt;j<localrows;j++){
			scaling = A_local[j][i]/tmp[i];
				for(k=i;k<nrows+1;k++){
					A_local[j][k] = A_local[j][k] - scaling*tmp[k];			
				}
				for (int w=0; w<=i; w++){
					A_local[j][w] = 0;	
				}
		}
	MPI_Barrier(MPI_COMM_WORLD);

        } 
	

// --------------------------------------------------------------------------------------------------------

	for ( int iter = 0; iter < localrows; iter++ ) {
		MPI_Isend(&A_local[iter][0], ncols, MPI_FLOAT, 0,NULL, MPI_COMM_WORLD, &request);
	}
	
	if(mynode == 0 )  {
		for ( int iter = 0 ; iter< localrows; iter++ ) {	
			for ( int node = 0; node < totalnodes; node++ )  {  	
				MPI_Irecv(&finalarray[(node*localrows + iter)*ncols], ncols, MPI_FLOAT, node,NULL, MPI_COMM_WORLD, &status);
			}
		}
		MPI_Wait(&request, &status);
	}


	if (mynode==0){
		for (int i=0; i<nrows; i++){
			for (int r = i*ncols; r < (i+1)*ncols; r++){
				cout << finalarray[r] << '\t'; 
				out << finalarray[r] << '\t'; 
			}
			cout << '\n';
			out << '\n';
		}	
	}




			
// --------------------------------------------------------------------------------------------------------
	MPI_Finalize();


	return(0);

}




