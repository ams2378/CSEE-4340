#define _XOPEN_SOURCE 600
#include <iostream>
#include <fstream>
#include<mpi.h>
#include <iomanip>
#include <math.h>

using namespace std;

	int nrows,ncols; 
	int i,j,k,data,input;
	int mynode, totalnodes;
	double scaling;
	ifstream is ("examplex.txt");
	ofstream out("output_mpi.txt");


	void mpi_rowassign_func();
