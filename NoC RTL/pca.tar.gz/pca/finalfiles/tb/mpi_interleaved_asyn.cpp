/*
Description: MPI implementation with interleaved assignment_ ASYNCHRONOUS.
Parallel computer architecture, HW1, Spring 2012
AMS2378
AT2769
*/

#include"mpi_interleaved_asyn.h"
#include"mpi_interleaved_asyn_func.cpp"	

int main(int argc, char *argv[]){

	is >> input;
        nrows = input;
        ncols = input+1;

	ptr = new float*[nrows];
							       
        for(int i = 0; i < nrows; i++){			
                   ptr[i] = new float[ncols];
	}

        for (int a=0; a<nrows; a++){
            for (int b=0; b<ncols; b++){
		is >> data;
		ptr[a][b] = data;
            }
	}

//------------------------------------------------------------MULTIPLE THREADS START HERE------------------------------------------

	MPI_Init(&argc,&argv);
	MPI_Comm_size(MPI_COMM_WORLD, &totalnodes);
	MPI_Comm_rank(MPI_COMM_WORLD, &mynode);				
	mpi_interleaved_asyn_func();
	return(0);

}




