/*
Description: SAS implementation with decomposition into rows assignment.
Parallel computer architecture, HW1, Spring 2012
AMS2378
AT2769
*/


#include"pthread_rowassign.h"
#include"pthread_rowassign_func.cpp"

int main(int argc, char *argv[]) {

	struct thread_data in[NUM_THREAD];
	pthread_t threads[NUM_THREAD];
	pthread_barrier_init(&barr, NULL, NUM_THREAD);
	pthread_mutex_init(&mutex, NULL);

	ifstream is ("example.txt");
	ofstream out("output_pthread_rowassigned.txt");
        int input;
        int data;
        int i=0;
	float** ptr;

        is >> input;
        n = input;
        int row = input;
        int col = input+1;

        ptr = new float*[row];
       
        for(int i = 0; i < row; i++){
   
                ptr[i] = new float[col];
	}

        for (int a=0; a<row; a++){
            for (int b=0; b<col; b++){
		is >> data;
		ptr[a][b] = data;
           }
	}

	for (int i=0; i<NUM_THREAD; i++){
		in[i].data = ptr;
	}


	for(int t=0; t<NUM_THREAD; t++){
   	     	in[t].pid = t;
		pthread_create(&threads[t], NULL, solve, (void *) &in[t]);
 	}

	for(int i = 0; i < NUM_THREAD; ++i)
	{
      	   	pthread_join(threads[i], NULL);
	}

	for (int k = 0; k < n; ++k) {
		for (int j = 0; j < n + 1; ++j){
	//		cout << ptr[k][j] << '\t';
	//		cout << '\n';
	 cout << ptr[k][j]/ptr[k][k] << '\t'; 			// for normalization
	 out << ptr[k][j]/ptr[k][k] << '\t';
		}
	 cout << '\n';
	 out << '\n';
	}

	delete [] ptr;
	return(0);
}


