// Final working code; consider '0' pivot element; with file IO
#define _XOPEN_SOURCE 600
#include <iostream>
#include <fstream>
#include<pthread.h>
#define NUM_THREAD 2

using namespace std;

int n;			// n = number of rows

struct thread_data{
	float** data;
	int pid;
};

pthread_barrier_t barr;
pthread_barrier_t barr2;
pthread_mutex_t mutex;


void* solve(void *thread_arg) {				// needed: pid, data, number of rows
	struct thread_data* my_data;
	my_data = (struct thread_data*) thread_arg;
	float** a;
	a = my_data->data;
	int id = my_data->pid;
	int* p = new int[NUM_THREAD];			// required for swaping
	int i, j, k, max, final;
	int i_temp = 1;
	float t;

	for (i = 0; i < n; ++i) {
	cout << "thread : " << id << "   before if" << endl;
	
	   if (i_temp%NUM_THREAD != id){
		cout << "thread : " << id << "   working" << endl;
		if (a[i][i] == 0){
			max = i;
			for (j = i + 1; j < n; ++j){
				if (j%NUM_THREAD == id){
					cout << "inside swap" << "  a[j][i] : " << a[j][i] << "  a[max][i] : " << a[max][i]<< endl;	
					if (a[j][i] > a[max][i])
						max = j;
						p[id] = max;
					cout << "a[j][i] : " << a[j][i] << "  a[max][i] : " << a[max][i] <<" max is : " << max << "  id is : " << id <<endl;
				}
				else 
					continue;
			}
			pthread_barrier_wait(&barr2);

			for (int m=0; m<=(id-1); m++){
				if(p[m]>p[m+1])
					final = p[m];
				else
				   	continue;			
			}	
			for (j = 0; j < n + 1; ++j) {
				t = a[final][j];
				a[final][j] = a[i][j];
				a[i][j] = t;
			}
		}
		
		else {
			for (j = n; j >= i; --j)
				for (k = i + 1; k < n; ++k)				// i = PIVOT
					a[k][j] -= a[k][i]/a[i][i] * a[i][j];		
		}		
	  }
		pthread_barrier_wait(&barr);
//	  else 
				
	}
      
//	   else
//		continue;


/*		for (k = 0; k < n; ++k) {
			for (j = 0; j < n + 1; ++j)
			cout << a[k][j] << '\t';
			cout << '\n';
		//	cout << a[k][j]/a[k][k] << '\t';				// for normalization
		//	cout << '\n';								
		}						*/	
//return 0;
}



int main(int argc, char *argv[]) {

	
	struct thread_data in[NUM_THREAD];
	pthread_t threads[NUM_THREAD];
	pthread_barrier_init(&barr, NULL, NUM_THREAD);
	pthread_barrier_init(&barr2, NULL, NUM_THREAD);
	
	pthread_mutex_init(&mutex, NULL);

	ifstream is ("example.txt");
        int input;
        int data;
        int i=0;
	float** ptr;

        is >> input;
      	n = input;
        int row = input;
        int col = input+1;

        ptr = new float*[row];
       
        for(int i = 0; i < row; i++){
   
                ptr[i] = new float[col];    
	}

        for (int a=0; a<row; a++){
            for (int b=0; b<col; b++){
		is >> data;                
		ptr[a][b] = data;
//		cout << "ptr [" << a << "][" << b << "]" <<  ptr[a][b] << endl;
           }
	}
	
	for (int i=0; i<NUM_THREAD; i++){
		in[i].data = ptr;
	}

	
	for(int t=0;   t<NUM_THREAD;   t++){
     		in[t].pid = t;
		cout <<"In main: creating thread : " << t << endl;
		pthread_create(&threads[t], NULL, solve, (void *) &in[t]);
 	}

//	solve(ptr, n);


	for(int i = 0; i < NUM_THREAD; ++i)
	    {
        	pthread_join(threads[i], NULL);
	    }

	for (int k = 0; k < n; ++k) {
		for (int j = 0; j < n + 1; ++j)
		cout << ptr[k][j] << '\t';
		cout << '\n';
	//	cout << a[k][j]/a[k][k] << '\t';				// for normalization
	//	cout << '\n';								
	}							

	pthread_mutex_destroy(&mutex);
	delete [] ptr;
	return(0);
}


