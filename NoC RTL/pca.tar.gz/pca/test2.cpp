#include <iostream>
#include <fstream>
using namespace std;

int main () {

        ifstream is ("example.txt");
            int input;
            int data;
            int i=0;
        is >> input;
      
        int row = input;
        int col = input+1;
        int **ptr;

        ptr = new int*[row];
       
        for(int i = 0; i < row; i++){
   
                ptr[i] = new int[col];    }

        for (int a=0; a<row; a++){
            for (int b=0; b<col; b++){
		is >> data;                
		ptr[a][b] = data;
            cout << "ptr [" << a << "][" << b << "]" <<  ptr[a][b] << endl;
           }
	}
return (0);

}
