#define _XOPEN_SOURCE 600
#include <pthread.h>
#include <iostream>
#include <fstream>
using namespace std; 
#define NUM_THREADS	2
#include <math.h>

// Barrier variable
pthread_barrier_t barr;

struct thread_data
{
   float **input;
   int nthread;
   int thread_id;
   int nrows;
};


void *Proc(void *t){
	struct thread_data* temp;
	temp = (struct thread_data*) t;
//	cout << "thread id is : " << temp->thread_id << endl;
	int row = temp->nrows;
	int col = row + 1; 
	for (int a=0; a<row; a++){
            for (int b=0; b<col; b++){           
		cout << "input [" << a << "][" << b << "] : " <<  temp->input[a][b] << endl;
           }
	}
	pthread_exit(NULL);
}


/*void *Proc (void *thread_arg ) {		} // end for proc;			*/

float** readinput(float** ptr,  struct thread_data* p, int* rows){

        ifstream is ("example.txt");
            int input;
            int data;
            int i=0;

        is >> input;
      	p->nrows = input;
        int row = input;
	rows = &input;
        int col = input+1;

        ptr = new float*[row];
       
        for(int i = 0; i < row; i++){
   
                ptr[i] = new float[col];    }

        for (int a=0; a<row; a++){
            for (int b=0; b<col; b++){
		is >> data;                
		ptr[a][b] = data;
//		cout << "ptr [" << a << "][" << b << "]" <<  ptr[a][b] << endl;
           }
	}
return(ptr);
}


/* Start of main */
int main(int argc, char *argv[]){
 

 struct thread_data in;
 struct thread_data* p = &in;
 
 float **ptr;
 int* nrows;
	
 p->input = readinput(ptr, p, nrows);
 p->nthread = NUM_THREADS;

 pthread_t threads[NUM_THREADS];

 for(int t=0;   t<NUM_THREADS;   t++){
     	in.thread_id = t;
	cout <<"In main: creating thread : " << t << endl;
	pthread_create(&threads[t], NULL, Proc, (void *) &in);
 }

 for (int i=0; i< NUM_THREADS; i++){

	pthread_join(threads[i], NULL);
 }
/*
 for ( int i =0; i< *nrows; i ++)  {
	for( int j =0; j< *nrows + 1 ; j++)  {
		cout<<"matrix["<<i<<"]["<<j<<"] : "<< ptr[i][j]<< endl;
	}
 }
*/		 
cout << "ALL DONE" << endl;
}

